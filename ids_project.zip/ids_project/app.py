
import streamlit as st
import joblib
import numpy as np

# Page configuration
st.set_page_config(
    page_title="Movie Revenue Predictor",
    page_icon="",
    layout="centered"
)

# Custom styling
st.markdown("""
<style>
    .main-header {
        text-align: center;
        color: #FF4B4B;
        padding: 1rem;
    }
    .stButton button {
        width: 100%;
        background-color: #FF4B4B;
        color: white;
        font-weight: bold;
    }
    .result-box {
        background-color: #f0f2f6;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

# Title
st.markdown('<h1 class="main-header"> Movie Revenue Predictor</h1>', unsafe_allow_html=True)
st.write("Predict how much money your movie will make based on key features.")

# Load model
@st.cache_resource
def load_model():
    try:
        model = joblib.load("model.pkl")
        scaler = joblib.load("scaler.pkl")
        return model, scaler
    except:
        return None, None

model, scaler = load_model()

if model is None:
    st.error(" Model files not found. Please check that 'model.pkl' and 'scaler.pkl' are in the same folder.")
    st.info("To create these files, train your model in the notebook and save it using:")
    st.code("""
    import joblib
    joblib.dump(model, 'model.pkl')
    joblib.dump(scaler, 'scaler.pkl')
    """)
    st.stop()

st.success("Model loaded successfully!")

# Input section in two columns
col1, col2 = st.columns(2)

with col1:
    st.subheader("💰 Budget & Popularity")
    budget = st.slider(
        "Budget (in millions)",
        min_value=1,
        max_value=400,
        value=50,
        help="How much money will be spent making the movie"
    )
    
    popularity = st.slider(
        "Popularity Score",
        min_value=0.0,
        max_value=100.0,
        value=50.0,
        step=0.1,
        help="How popular the movie is expected to be (0-100)"
    )
    
    runtime = st.slider(
        "Runtime (minutes)",
        min_value=60,
        max_value=240,
        value=120,
        help="Length of the movie in minutes"
    )

with col2:
    st.subheader(" Quality & Details")
    rating = st.slider(
        "Expected Rating",
        min_value=0.0,
        max_value=10.0,
        value=6.5,
        step=0.1,
        help="Predicted rating from critics/audience (0-10)"
    )
    
    language = st.selectbox(
        "Primary Language",
        ["English", "Other"],
        help="Main language of the movie"
    )
    
    year = st.slider(
        "Release Year",
        min_value=2000,
        max_value=2025,
        value=2023,
        help="When the movie will be released"
    )

# Convert inputs
budget_dollars = budget * 1_000_000
lang_code = 0 if language == "English" else 1

# Prediction button
if st.button(" Predict Movie Revenue", type="primary"):
    
    # Prepare features
    features = [[budget_dollars, popularity, runtime, rating, lang_code, year]]
    features_scaled = scaler.transform(features)
    
    # Make prediction
    prediction_scaled = model.predict(features_scaled)[0]
    
    # Convert to dollars (simplified for demo)
    if prediction_scaled > 0:
        # Positive prediction
        predicted_revenue = budget_dollars * (2.5 + prediction_scaled * 0.3)
        profit_color = "green"
        profit_text = "💰 Profitable Investment"
    else:
        # Negative prediction
        predicted_revenue = budget_dollars * (0.7 + prediction_scaled * 0.1)
        profit_color = "orange"
        profit_text = " Risky Investment"
    
    # Calculate metrics
    profit = predicted_revenue - budget_dollars
    roi = (profit / budget_dollars) * 100
    
    # Display results
    st.markdown("---")
    st.markdown(f"### Prediction Results")
    
    # Results in columns
    res_col1, res_col2 = st.columns(2)
    
    with res_col1:
        st.metric(
            label="Predicted Revenue",
            value=f"${predicted_revenue:,.0f}",
            delta=f"{roi:.1f}% ROI"
        )
        
    with res_col2:
        st.metric(
            label="Budget",
            value=f"${budget_dollars:,.0f}",
            delta=f"${profit:,.0f}"
        )
    
    # Profitability indicator
    if profit > 0:
        st.success(f"**{profit_text}** - Expected profit of ${profit:,.0f}")
    else:
        st.warning(f"**{profit_text}** - Expected loss of ${abs(profit):,.0f}")
    
    # Detailed breakdown
    with st.expander(" View Detailed Breakdown"):
        col_a, col_b, col_c = st.columns(3)
        
        with col_a:
            st.write("**Model Score**")
            st.write(f"{prediction_scaled:.4f}")
            st.caption("Higher is better")
        
        with col_b:
            st.write("**Budget Multiplier**")
            multiplier = predicted_revenue / budget_dollars
            st.write(f"{multiplier:.2f}x")
            st.caption("Revenue ÷ Budget")
        
        with col_c:
            st.write("**Risk Level**")
            if roi > 50:
                st.write("Low Risk")
            elif roi > 0:
                st.write("Medium Risk")
            else:
                st.write("High Risk")

# Information section
st.markdown("---")
st.markdown("### ℹ️ How It Works")

with st.expander("Learn about the model"):
    st.write("""
    This predictor uses a machine learning model trained on **4,803 real movies** 
    from the TMDB dataset. It analyzes 6 key features:
    
    1. **Budget** - Production cost in dollars
    2. **Popularity** - Audience interest score
    3. **Runtime** - Movie length in minutes
    4. **Rating** - Expected quality score (0-10)
    5. **Language** - English vs. other languages
    6. **Release Year** - When the movie comes out
    
    The model finds patterns between these features and actual box office revenue 
    to make predictions.
    """)
    

    st.write("**Feature Importance (Sample):**")
    importance_data = {
        'Feature': ['Budget', 'Popularity', 'Rating', 'Runtime', 'Language', 'Year'],
        'Impact': ['High', 'High', 'Medium', 'Low', 'Medium', 'Low']
    }
    
 
    import pandas as pd
    df = pd.DataFrame(importance_data)
    st.dataframe(df, use_container_width=True, hide_index=True)

st.markdown("---")
st.caption(" Built with Streamlit | Model trained on TMDB 5000 Movies Dataset")